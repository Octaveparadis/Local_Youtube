<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Front extends CI_Controller {

	public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('General');
    }

	public function index()
	{
		$recommand_items = $this->General->get_recommand_items('img_items', 'favorite', 4);
		$items_images_arr = $this->General->get_recommand_item_images($recommand_items);
		$data['recommand_items'] = $recommand_items;
        $data['recommand_items_images'] = $items_images_arr;
        $category = $this->General->get_all('category', 'no');
        $cate_recom_items = array();
        $cate_recom_items_images = array();
        foreach ($category as $key => $value) {
        	$cond['category'] = $value->id;
        	$cate_recom_items[$key] = $this->General->get_cate_recommand_items('img_items', $cond, 'favorite', 4);
        	$cate_recom_items_images[$key] = $this->General->get_recommand_item_images($cate_recom_items[$key]);
        }
        $data['category'] = $category;
        $data['cate_recom_items'] = $cate_recom_items;
        $data['cate_recom_items_images'] = $cate_recom_items_images;
		$this->load->view('index1', $data);
	}

	

	public function go_video_index2(){
		$this->load->view('index2');
	}	

	public function go_playback()
	{
		//////////      This is the Text displayed at the bottom of the screen.   /////////////

		
		$item_id = $_GET['item_id'];
		$cond['id'] = $item_id;
		$select_item = $this->General->get_row('img_items', $cond);
		$cond2['item_id'] = $item_id;
		$item_images = $this->General->get_rows('item_images', $cond2);
		$all_items = $this->General->get_all('img_items', 'no');
		$items_images_arr = array();
        foreach ($all_items as $item){
            // $cond1['id'] = $item->category;
            // $category = $this->General->get_row('category', $cond1);            
            // array_push($category_arr, $category->category_name);
            $cond2['item_id'] = $item->id;
            $item_image = $this->General->get_row('item_images', $cond2);            
            array_push($items_images_arr, $item_image->img_url);
        }
        $cond3['id'] = '1';
        $setting_second = $this->General->get_row('setting', $cond3);
		$data['item'] = $select_item;
		$data['item_images'] = $item_images;
		$data['all_items'] = $all_items;
		$data['all_images'] = $items_images_arr;
		$data['switching_scond'] = $setting_second->img_switching_second;
		$this->load->view('playback', $data);
	}

	public function go_videoplay()
	{
		$data['item'] = $_GET['item'];
		$this->load->view('videoplay', $data);
	}

}
