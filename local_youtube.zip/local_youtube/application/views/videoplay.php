﻿
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>ローカルで動くYoutubeもどきWebページ</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="../assets/images/logo.png">

    <!-- Bootstrap framework main css -->
    <link rel="stylesheet" href="../assets/css/bootstrap.min.css">
    <!--Custom css-->
    <link rel="stylesheet" href="../assets/css/style.css">
    <!-- jquery JS -->
    <script src="../assets/js/jquery.min.js"></script>
    <script src="../assets/js/bootstrap.min.js"></script>

    <!-- ----  video.js  ---- -->
    <link href="https://vjs.zencdn.net/7.5.4/video-js.css" rel="stylesheet">
    <script src="https://vjs.zencdn.net/ie8/1.1.2/videojs-ie8.min.js"></script>
    <link href="../assets/css/mdi-icons/css/materialdesignicons.min.css" media="all" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<style type="text/css">
 .video-js .vjs-big-play-button {    
    top: 45%;
    left: 45%;   
  }
</style>

</head>
<body>

    <div class="app-content content">
      <div class="content-wrapper" style="padding: 1rem 2.2rem; box-shadow: 5px 10px 18px #eeeeee;">
        <div class="row color60">
          <div class="col-md-2" style="min-width: 180px;">
            <div class="row">
              <div class="col-sm-2">
                <span class="mdi mdi-menu" style="font-size: 27px;"></span>
              </div>
              <div class="col-sm-10">
                <span class="mdi mdi-youtube" style="color: red;font-size: 27px; margin-left: 5px;"></span>
                <span style="font-size: 20px;font-family: fantasy;color: black;">Youtube</span>
                <span style="font-size: 12px;font-weight: bold;position: absolute; margin-top: 5px;margin-left: 5px;">JP</span>
              </div>
            </div>
          </div>
          <div class="col-md-7">
            <form class="example" action="/action_page.php">
              <input type="text" placeholder="検索" name="search">
              <button type="submit"><i class="fa fa-search" style="color: black;"></i></button>
            </form>
          </div>
          <div class="col-md-3">
            <div class="row">
              <div class="col-sm-2">
                <span class="mdi mdi-video-plus" style="font-size: 27px;"></span>
              </div>
              <div class="col-sm-2">
                <span class="mdi mdi-grid" style="font-size: 27px; color: black;"></span>
              </div>
              <div class="col-sm-2">
                <span class="mdi mdi-share" style="font-size: 27px;"></span>
              </div>
              <div class="col-sm-2">
                <span class="mdi mdi-dots-vertical" style="font-size: 27px;"></span>
              </div>
              <div class="col-sm-4">
                <div style="width: 100%;height: 100%;max-width: 100px; min-width: 100px; padding: 2px;border: 2px solid #1363D1;border-radius: 3px;color: #1363D1;">
                    <div style="float: left;margin-top: -3px;">
                      <span class="mdi mdi-account-circle" style="font-size: 25px;"></span>
                    </div>
                    <div style="float: left;margin-top: 5px;margin-left: 5px;">
                      <span style="font-size: 14px;">ログイン</span>
                    </div>                  
                </div>
              </div>
            </div>
          </div>
        </div>      
    </div>
      <div class="content-wrapper" style="padding: 1rem 2.2rem;">
        <div class="row">
          <div class="col-md-7">
            <div class="video">
              <div class="video-holder">
                <div class="youtube" data-embed="PuGpgHT1Dxc">                  
                    <video id='my-video' class='video-js' controls preload='auto' data-setup='{}' style="width: 100%;height: 100%;">
                      <source src='../assets/video/<?php echo $item;?>.mp4' type='video/mp4'>                   
                      <p class='vjs-no-js'>
                        To view this video please enable JavaScript, and consider upgrading to a web browser that
                        <a href='https://videojs.com/html5-video-support/' target='_blank'>supports HTML5 video</a>
                      </p>
                    </video>
                </div>
              </div>
            </div>
            <p class="pt-1 mb-0" style="font-weight: bold;color: black;">結婚式のプロフィールムービ</p>
            <div class="row pb-1" style="border-bottom: 1px solid #c3c3c3;">
              <div class="col-md-6">
                <span class="mb-1">23,232,242 回視聴</span>
              </div>
              <div class="col-md-6 p-0 m-0">
                <div class="row">
                  <div style="width: 20%;float: left;padding: 0 5px;">
                    <span class="mdi mdi-thumb-up" style="font-size: 15px;"></span>
                    <span>149万</span>
                  </div>             
            
                  <div style="width: 20%;float: left;padding: 0 5px;">
                    <span class="mdi mdi-thumb-down"></span>
                    <span>7.2万</span>
                  </div>

                  <div style="width: 20%;float: left;padding: 0 5px;">
                    <span class="mdi mdi-share" style="font-size: 20px;line-height: 20px;"></span>
                    <span>共有</span>
                  </div>

                  <div style="width: 20%;float: left;padding: 0 5px;">
                    <span class="mdi mdi-playlist-plus" style="font-size: 20px;line-height: 20px;"></span>
                    <span>保存</span>
                  </div>

                  <div style="width: 20%;float: left;padding: 0 5px;">
                    <span class="mdi mdi-dots-horizontal" style="font-size: 25px;line-height: 25px;"></span>                  
                  </div>
                </div>
              </div>
            </div>
            <div class="row intro-title">
              <div style="margin-right: 10px;">
                <img class="channel-profile" src="../assets/images/gallery/12_5.jpg">
              </div>
              <div class="col-sm-3">
                <div class="row">
                  <span style="line-height: 22px;font-size: 13px">米濉玄師</span>
                </div>
                <div class="row">
                  <span class="recommand-channel" style="line-height: 12px;font-size: 12px;">2018/02/26 に公翻</span>
                </div>
              </div>              
              
              <div class="register-btn" style="right: 15px;">
                <span>チャンネル登録</span>&nbsp; <span>23万</span>
              </div>
            </div>
          </div>

          <div class="col-md-5" style="min-width: 475px;">
            <img id="ad-img" src="../assets/images/gallery/IMG_3805.JPG" style="width: 60%;height: 200px;">
            
            <div class="row mt-1 p-1">
              <span style="color: black;font-size: 17px;">次の動画</span>
              <div style="position: absolute;right: 2.5rem;line-height: 14px;">
                <span class="color60" style="font-size: 14px;">自動再生</span>
                <label class="switch">
                  <input type="checkbox" checked>
                  <span class="slider round"></span>
                </label>
              </div>
            </div>
            
            <?php for($i = 1; $i <= 12; $i++){ 
              if ($i != $item) {            
            ?>
              <div class="row mb-1" onclick="item_play(<?php echo $i;?>)">
                <div class="col-sm-5">
                  <img id="ad-img" src="../assets/images/gallery/<?php echo $i; ?>_1.jpg" style="max-width: 198px;width: 100%;height: 100px;">
                </div>
                <div class="col-sm-7">
                  <p class="mb-0" style="font-weight: bold;">結婚式のプロフィールムービ</p>
                  <p class="mb-0" style="font-weight: bold;">Music Video</p>
                  <p class="mb-0">liooikjl</p>
                  <p class="mb-0">eregfgtre</p>
                </div>
              </div>
            <?php }} ?>
          </div>
        </div>
      </div>
    </div>
        <!-- <div class="col-md-6">
          <div class="video">
            <div class="video-holder">
              <div class="youtube" data-embed="PuGpgHT1Dxc">
                <div class="play-button"></div>
              <img src="https://img.youtube.com/vi/PuGpgHT1Dxc/sddefault.jpg" style="width: 100%;"></div>
            </div>
          </div>
        </div> -->
      
       
       

    <script>
        
        $(document).ready(function () {
            var video_W = $('.video').width();
            var video_H = video_W * 360 / 635;
            $('.video').css('height', video_H + 'px');
            let youtube = $('.youtube');
            for (let i = 0; i < youtube.length; i++) {

              // youtube[i].addEventListener("click", function() {
              //   let iframe = document.createElement("iframe");
              //   iframe.setAttribute("frameborder", "0");
              //   iframe.setAttribute("allowfullscreen", "");
              //   iframe.setAttribute("src", "https://www.youtube.com/embed/"+ this.getAttribute('data-embed') +"?autoplay=1&rel=0");
              //   iframe.style.width = "100%";
              //   iframe.style.height = "100%";
              //   this.innerHTML = "";
              //   this.appendChild(iframe);
              // } );

              // youtube[i].addEventListener("click", function() {
              //   let video = document.createElement("video");
              //   video.setAttribute("autoplay", "");
              //   video.setAttribute("controls", "");
              //   video.style.width = "100%";
              //   video.style.height = "100%";
              //   let source = document.createElement("source");
              //   source.setAttribute("src", "../assets/video/<?php echo $item;?>.mp4");
              //   source.setAttribute("type", "video/mp4");
              //   video.appendChild(source);
              //   this.innerHTML = "";
              //   this.appendChild(video);
              // } );

            }
        });

        function item_play(item){
          location.href = "<?php echo base_url('Front/go_videoplay?item=')?>" + item;
        }
      
        
    </script>

    <script src='https://vjs.zencdn.net/7.5.4/video.js'></script>
</body>
</html>
