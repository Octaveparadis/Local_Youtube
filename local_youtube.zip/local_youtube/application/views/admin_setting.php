﻿
                <div class="col-10 pl-4 pr-4 pt-0" style="background-color: #FAFAFA;">
                  <div id="content-wrapper">  
                    <div class="card mb-3">
                          
                          <div class="card-body" style="background-color: #FAFAFA;">
                              <div class="card mb-3">
                                  
                                  <div class="card-body">
                                      <div class="row">
                                      
                                         <div class="col-sm-4" style="text-align: center;">
                                            <span style="line-height: 40px;">画像の切り替え秒数</span>
                                         </div>
                                         <div class="col-sm-5">                                                                
                                              <input type="text" id="switch_second" style="width: 80%;" class="form-control" required="required" value="<?php echo $second;?>" />
                                             
                                          </div>
                                          <div class="col-sm-3" style="text-align: center;">
                                              <button class="btn btn-primary" style="" type="button" onclick="javascript:change_second()">Change</button>
                                          </div>
                                      
                                      </div>

                                  </div>
                              </div>
                          
                          </div>
                          
                    </div>

                  </div>
                    
              
                </div>
              </div>
            </div>
            <!--/ Image grid -->
          </div>
          
        </section>
      </div>
    </div>
  </div>
    
<script type="text/javascript">

   $('#add_img').removeClass('active');
   $('#setting').addClass('active');
   $('#setting_icon').css('color', 'red');
   $('#image_icon').css('color', '#606060');

  
   //////////////////////////////////////////////////////////
            function change_second(){
              var new_second = $('#switch_second').val();
              if (new_second.length < 1) {
                alert('Please input second');
                return;
              }
              else{
                $.post('change_second', {'second': new_second},
                    function (data) {                        
                        var result = JSON.parse(data);
                        if (result['state'] == "success") {
                            alert("Changed OK!");
                            location.reload();                            
                            
                        } else {
                            alert('warning');
                        }

                    }
                );
              }
            }

</script>