﻿                <div class="col-10 pl-4 pr-4 pt-0" style="background-color: #FAFAFA;">
                 
                  <div id="content-wrapper">  
                    <div class="card mb-3">
                      
                      <div class="card-body" style="background-color: #FAFAFA;">
                          <div class="card mb-3">
                             
                              <div class="card-body">
                                  <div class="row">
                                      <div class="col-sm-6" style="text-align: center;">   
                                        <div class="row pl-4">  
                                          <span style="line-height: 40px;">Category: &nbsp;</span>                           
                                          <select id="category" style="width: 200px;height: 40px;" autofocus>
                                            <option value="0">Select Category</option>
                                            <?php if (isset($categories)) {                                              
                                              foreach ($categories as $key => $category) {  ?>
                                              <option value="<?php echo $category->id;?>"><?php echo $category->category_name; ?></option>
                                            <?php } } ?>
                                          </select>
                                        </div>
                                        <div class="row pt-2 pl-4">     
                                          <span style="line-height: 40px;">Title: &nbsp;</span>                                    
                                          <input type="text" id="title" style="width: 80%; float:left;" class="form-control" required="required" placeholder="Input new item title">
                                        </div>
                                        <div class="col-sm-9 pt-2 ml-auto mr-auto">
                                          <input id="chooseLocalVideo" type="file"/>
                                        </div>
                                      </div>    
                                      <div class="col-sm-6"> 
                                        <div class="row">
                                          <span style="line-height: 40px;">Views: &nbsp;</span>
                                          <input type="number" id="views" style="width: 60%;" class="form-control" required="required" placeholder="Input the number of views" value="0">
                                        </div>
                                        <div class="row pt-2">
                                          <span style="line-height: 40px;">Favorites: &nbsp;</span>
                                          <input type="number" id="favorites" style="width: 60%;" class="form-control" required="required" placeholder="Input the number of favorites" value="0">
                                        </div>
                                        <div class="row pt-2">
                                          <span style="line-height: 40px;">Disgusts: &nbsp;</span>
                                          <input type="number" id="disgusts" style="width: 60%;" class="form-control" required="required" placeholder="Input the number of disgusts" value="0">
                                        </div>
                                      </div>  
                                  </div>                                 
                                
                                   <div class="row mt-2">
                                    <div class="col-sm-6 mr-auto ml-auto" style="text-align: center;">
                                      <button class="btn btn-primary" style="width: 50%;" type="button" onclick="javascript:add_video()">Add</button>
                                    </div>
                                  </div>
                              </div>
                          </div>

                          <div class="input-group" style="width: 300px;float:right;">
                              <input type="text" id="search_item" class="form-control" placeholder="Enter the item name..." aria-label="Search" aria-describedby="basic-addon2">
                              <div class="input-group-append" onclick="javascript:search_item()">
                                  <button class="btn btn-primary" type="button">
                                      <i class="fa fa-search"></i>
                                  </button>
                              </div>
                          </div>
                          <div class="table-responsive">
                              <table class="table table-bordered table-striped" id="dataTable" width="50%" cellspacing="0" style="margin-top: 20px;background-color: white;">
                                  <thead>
                                  <tr>
                                      <th>No</th>
                                      <th>Title</th>
                                      <!-- <th>Intro Image</th> -->
                                      <th>Category</th>
                                      <th>Views</th>
                                      <th>Favorites</th>
                                      <th>Disgusts</th>
                                      <!-- <th>Date and Time</th> -->
                                      <th>Operation</th>
                                  </tr>
                                  </thead>
                                  <tbody id="item-table">
                                  <tr>
                                      <td colspan="7">No Item</td>
                                  </tr>
                                  </tbody>
                              </table>
                          </div>
                      </div>
                      
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!--/ Image grid -->
          </div>
          
        </section>
      </div>
    </div>
  </div>
    
 <script type="text/javascript">
   $('#add_img').removeClass('active');
   $('#add_video').addClass('active');
   $('#video_icon').css('color', 'red');
   $('#image_icon').css('color', '#606060');

    $(document).ready(function() {
          load_videos();
    }); 

    function load_videos(){
      $.get('all_videos',
          function (data) {              
              var result = JSON.parse(data);              
              if (result['state'] == "success") {
                        var videos = result['videos'];
                        var category_names = result['category_names'];    
                        var items_images = result['items_images'];                    
                        var tbhtml = "";
                        for (var i = 0; i < videos.length; i++) {
                            var num = i+1;
                            var video = videos[i];
                            var title = video['title'];                            
                            var video_id = video['id'];
                            // var item_img = items_images[i];
                            var category = category_names[i];
                            var views = video['views'];
                            var disgusts = video['disgust'];
                            var favorites = video['favorite'];
                            var date = video['created_at'];
                            tbhtml += '<tr>';
                            tbhtml += '<td>' + num + '</td>';
                            tbhtml += '<td>';                          
                            tbhtml += '<span id = "title_'+i+'">' + title + '</span>';
                            tbhtml += '</td>';
                            // tbhtml += '<td><img id="icon" src="../../uploads/images/'+item_img+'" style="width: 50px;height: 40px;background-size: 100% 100%;background-repeat: no-repeat"></td>';
                            tbhtml += '<td>'+category+'</td>';   
                            tbhtml += '<td>'+views+'</td>';   
                            tbhtml += '<td>'+favorites+'</td>'; 
                            tbhtml += '<td>'+disgusts+'</td>';    
                            //tbhtml += '<td>'+date+'</td>';                
                            tbhtml += '<td>';                            
                            tbhtml += '<button class="btn btn-info" type="button" onclick="edit_item_name(\''+title+'\','+video_id+')">Edit</button>&emsp;';
                            tbhtml += '<button class="btn btn-danger" type="button" onclick="delete_item('+video_id+')">Delete</button>';
                            tbhtml += '</td>';
                            tbhtml += '</tr>';
                        }
                        $('#item-table').html(tbhtml);
                    } else {
                        var tbhtml = "";
                        tbhtml +='<tr><td colspan="7">No Item</td></tr>';
                        $('#dataTable').html(tbhtml);
              }
          }
      );
    }
    var video_file;
    function readURL(input) {
        if (input.files && input.files[0]) {
            var reader = new FileReader();
            // reader.onload = function (e) {
            //     $('#slide_img' + cnt).attr('src', e.target.result);
            // }
            reader.readAsDataURL(input.files[0]);
            video_file = input.files[0];
            console.log(video_file);
        }
    }
    
    $("#chooseLocalVideo").change(function(){          
        readURL(this);            
    });

    function add_video(){
          
          var sel_category = $('#category').val();
          var title = $('#title').val();
          var views = $('#views').val();
          var favorites = $('#favorites').val();
          var disgusts = $('#disgusts').val();
          if (sel_category == 0) {
            alert("Please select category.");
            return;
          }
          else if(title.length < 1){
            alert("Please Input Title.");
            return;
          }
          else if (video_file == null) {
            alert("Please select video.");
            return;
          }
          else{
            var formData = new FormData();           
                  formData.append('category', sel_category);
                  formData.append('title', title);
                  formData.append('views', views);
                  formData.append('favorites', favorites);
                  formData.append('disgusts', disgusts);             
                  formData.append('video', video_file, video_file.fileName);                   
                                  
                    $.ajax({
                        type: "POST",
                        url: 'add_video',
                        success: function (data, textStatus, jqXHR) {
                            var result = JSON.parse(data);
                            console.log(result);
                            if (result['state'] == "success") {
                                location.reload();
                                video_file = null;
                                
                            }
                            else {
                                alert("warning");
                            }
                        },
                        error: function (jqXHR, textStatus, errorThrown) {
                            message('danger', textStatus + ': ' + errorThrown);
                        },
                        async: true,
                        data: formData,
                        cache: false,
                        contentType: false,
                        processData: false
                    });
          }
        }

 </script>