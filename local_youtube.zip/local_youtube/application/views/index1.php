﻿
<!doctype html>
<html class="no-js" lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>ローカルで動くYoutubeもどきWebページ</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Favicon -->
    <link rel="shortcut icon" type="image/x-icon" href="../assets/images/logo.png">

    <!-- Bootstrap framework main css -->
    <link rel="stylesheet" type="text/css" href="../assets/css/vendors.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/photo-swipe/photoswipe.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/photo-swipe/default-skin/default-skin.css">
    <!-- END VENDOR CSS-->
    <!-- BEGIN MODERN CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/app.css">
    <!-- END MODERN CSS-->
    <!-- BEGIN Page Level CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/core/colors/palette-gradient.css">
    <link rel="stylesheet" type="text/css" href="../assets/css/pages/gallery.css">
    <!-- END Page Level CSS-->
    <!-- BEGIN Custom CSS-->
    <link rel="stylesheet" type="text/css" href="../assets/css/style.css">
    <!-- <script src="js/jquery.min.js"></script> -->
    <!-- material design icons -->
    <link href="../assets/css/mdi-icons/css/materialdesignicons.min.css" media="all" rel="stylesheet" type="text/css" />

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>

<body style="background: #ffffff;">

  <div class="app-content content">
    <div class="content-wrapper" style="padding: 1rem 2.2rem; box-shadow: 5px 10px 18px #eeeeee;">
        <div class="row color60">
          <div class="col-md-2" style="min-width: 180px;">
            <div class="row">
              <div class="col-sm-2">
                <span class="mdi mdi-menu" style="font-size: 27px;"></span>
              </div>
              <div class="col-sm-10">
                <span class="mdi mdi-youtube" style="color: red;font-size: 27px; margin-left: 5px;"></span>
                <span style="font-size: 20px;font-family: fantasy;color: black;">Youtube</span>
                <span style="font-size: 12px;font-weight: bold;position: absolute; margin-top: 5px;margin-left: 5px;">JP</span>
              </div>
            </div>
          </div>
          <div class="col-md-7">
            <form class="example" action="/action_page.php">
              <input type="text" placeholder="検索" name="search">
              <button type="submit"><i class="fa fa-search" style="color: black;"></i></button>
            </form>
          </div>
          <div class="col-md-3">
            <div class="row">
              <div class="col-sm-2 btn-pointer">
                <span class="mdi mdi-video-plus" style="font-size: 27px;"></span>
              </div>
              <div class="col-sm-2 btn-pointer">
                <span class="mdi mdi-grid" style="font-size: 27px; color: black;"></span>
              </div>
              <div class="col-sm-2 btn-pointer">
                <span class="mdi mdi-share" style="font-size: 27px;"></span>
              </div>
              <div class="col-sm-2 btn-pointer">
                <span class="mdi mdi-dots-vertical" style="font-size: 27px;"></span>
              </div>
              <div class="col-sm-4">
                <div class="login-btn">
                    <div style="float: left;margin-top: -3px;">
                      <span class="mdi mdi-account-circle" style="font-size: 25px;"></span>
                    </div>
                    <div style="float: left;margin-top: 5px;margin-left: 5px;">
                      <span style="font-size: 14px;">ログイン</span>
                    </div>                  
                </div>
              </div>
            </div>
          </div>
        </div>      
    </div>
    <div class="content-wrapper">
      <div class="content-body">
        <section id="image-gallery" class="card">
          
          <div class="card-content">              
            <div class="card-body  my-gallery p-0">
              <div class="row ml-0">
                <div class="col-2 ml-0" style="background-color: #F5F5F5;">
                  <div class="row">
                    <div class="sel-item active" onclick="select_img()">
                      <div class="row">
                        <div class="col-sm-3">
                          <span class="mdi mdi-home" style="color: red;font-size: 25px;line-height: 25px;"></span>
                        </div>
                        <div class="col-sm-9" style="text-align: left;">
                          <span style="font-size: 17px;line-height: 25px;">画像</span>
                        </div>
                      </div>                     
                      
                    </div>
                  </div>
                  <div class="row">
                    <div class="sel-item" onclick="select_video()" style="">
                      <div class="row">
                        <div class="col-sm-3">
                          <span class="mdi mdi-fire" style="color: #606060;font-size: 25px;line-height: 25px;"></span>
                        </div>
                        <div class="col-sm-9" style="text-align: left;">
                          <span style="font-size: 17px;line-height: 25px;">動画</span>
                        </div>
                      </div>                      
                    </div>
                  </div>
                  <div class="row">
                    <div class="sel-item" onclick="select_video()" style="border-bottom: 1px solid #c3c3c3;">
                      <div class="row">
                        <div class="col-sm-3">
                          <span class="mdi mdi-animation-play" style="color: #606060;font-size: 25px;line-height: 25px;"></span>
                        </div>
                        <div class="col-sm-9" style="text-align: left;">
                          <span style="font-size: 17px;line-height: 25px;">動画</span>
                        </div>
                      </div>                      
                    </div>
                  </div>
                  <div class="row">
                    <div class="sel-item" onclick="select_video()" style="">
                      <div class="row">
                        <div class="col-sm-3">
                          <span class="mdi mdi-folder" style="color: #606060;font-size: 25px;line-height: 25px;"></span>
                        </div>
                        <div class="col-sm-9" style="text-align: left;">
                          <span style="font-size: 17px;line-height: 25px;">動画</span>
                        </div>
                      </div>                      
                    </div>
                  </div>
                  <div class="row">
                    <div class="sel-item" onclick="select_video()" style="border-bottom: 1px solid #c3c3c3;">
                      <div class="row">
                        <div class="col-sm-3">
                          <span class="mdi mdi-restore-clock" style="color: #606060;font-size: 25px;line-height: 25px;"></span>
                        </div>
                        <div class="col-sm-9" style="text-align: left;">
                          <span style="font-size: 17px;line-height: 25px;">動画</span>
                        </div>
                      </div>                      
                    </div>
                  </div>
                  <div class="row">
                    <div class="txtandlogin">                     
                      <span style="font-size: 17px;line-height: 25px;">動画の評価、コメント、チ ヤンネル登録を行うにはロ グインしてください。</span>
                      <br>
                      <div class="login-btn" style="height: 40px;">
                          <div style="float: left;margin-top: -3px;">
                            <span class="mdi mdi-account-circle" style="font-size: 25px;"></span>
                          </div>
                          <div style="float: left;margin-top: 2px;margin-left: 5px;">
                            <span style="font-size: 14px;">ログイン</span>
                          </div>                  
                      </div>
                    </div>
                  </div>
                  <div class="row">
                    <div class="txtandlogin" style="text-align: left;border: none;">
                      <div class="row">                        
                        <div class="col-sm-12" style="text-align: left;">
                          <span style="font-size: 17px;line-height: 25px;font-weight: bold;color: #919399;">BEST OF YOUTUBE</span>
                        </div>
                      </div>                      
                    </div>
                  </div>
                  <div class="row">
                    <div class="sel-item" onclick="select_video()">
                      <div class="row">
                        <div class="col-sm-3">
                          <span class="mdi mdi-music-circle" style="color: black;font-size: 25px;line-height: 25px;"></span>
                        </div>
                        <div class="col-sm-9" style="text-align: left;">
                          <span style="font-size: 17px;line-height: 25px;">動画</span>
                        </div>
                      </div>                      
                    </div>
                  </div>
                  <div class="row">
                    <div class="sel-item" onclick="select_video()">
                      <div class="row">
                        <div class="col-sm-3">
                          <span class="mdi mdi-star-circle" style="color: black;font-size: 25px;line-height: 25px;"></span>
                        </div>
                        <div class="col-sm-9" style="text-align: left;">
                          <span style="font-size: 17px;line-height: 25px;">動画</span>
                        </div>
                      </div>                      
                    </div>
                  </div>
                  <div class="row">
                    <div class="sel-item" onclick="select_video()">
                      <div class="row">
                        <div class="col-sm-3">
                          <span class="mdi mdi-heart-circle" style="color: black;font-size: 25px;line-height: 25px;"></span>
                        </div>
                        <div class="col-sm-9" style="text-align: left;">
                          <span style="font-size: 17px;line-height: 25px;">動画</span>
                        </div>
                      </div>                      
                    </div>
                  </div>
                </div>


                <div class="col-10 pl-4 pr-4 pt-0" style="background-color: #FAFAFA;">
                  <div class="row intro-title">
                    <span>最近アップロードされた動画</span>&nbsp;&nbsp;&nbsp;
                    <span class="recommand-channel">おすすめの動画</span>
                  </div>
                  <div class="row" style="border-bottom: 1px solid #E1E1E1;">
                    <?php if (isset($recommand_items)) {                     
                     foreach ($recommand_items as $key => $item) {                    
                     ?>

                    <div class="col-lg-3 col-md-6 col-12 mb-1" itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
                      <a href="<?php echo base_url ('Front/go_playback?item_id='.$item->id)?>" itemprop="contentUrl" data-size="480x360">
                          <img class="img-thumbnail img-fluid" src="../uploads/images/<?php echo $recommand_items_images[$key];?>" itemprop="thumbnail" alt="Image description" />
                      </a>
                      <p class="p-0 m-0" style="font-weight: bold;color: black;">結婚式のプロフィールムービ</p>                        
                      <p class="m-0" style="padding-top: 5px;font-weight: bold;font-size: 12px;">dsfdsfdf hfgfj</p>
                      <p class="p-0 m-0" style="font-weight: bold;font-size: 12px;">44444</p>
                    </div>    
                    
                    <?php } } ?>
                  </div>
                  
                  <?php if(isset($category)){
                    foreach ($category as $key => $cate_item) {
                      
                    ?>
                  <div class="row intro-title">
                    <img class="channel-profile" src="/uploads/category/<?php echo $cate_item->category_icon;?>">&nbsp;&nbsp;&nbsp;
                    <span style="line-height: 40px;"><?php echo $cate_item->category_name;?></span>&nbsp;&nbsp;&nbsp;
                    <span class="recommand-channel" style="line-height: 40px;">おすすめのチヤンネル</span>
                    <div class="register-btn">
                      <span>チャンネル登録</span>&nbsp; <span>23万</span>
                    </div>
                  </div>

                  <div class="row" style="border-bottom: 1px solid #E1E1E1;">
                    <?php                
                      foreach($cate_recom_items[$key] as $i => $item){?>

                    <div class="col-lg-3 col-md-6 col-12 mb-1" itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
                      <a href="<?php echo base_url ('Front/go_playback?item_id='.$item->id)?>" itemprop="contentUrl" data-size="480x360">
                          <img class="img-thumbnail img-fluid" src="/uploads/images/<?php echo $cate_recom_items_images[$key][$i];?>" itemprop="thumbnail" alt="Image description" />
                      </a>
                      <p class="p-0 m-0" style="font-weight: bold;color: black;"><?php echo $item->title;?></p>                        
                      <p class="m-0" style="padding-top: 5px;font-weight: bold;font-size: 12px;">dsfdsfdf hfgfj</p>
                      <p class="p-0 m-0" style="font-weight: bold;font-size: 12px;"><?php echo $item->views?></p>
                    </div>    
                    
                    <?php } ?>
                  </div>
                  <?php } }?>
                </div>
              </div>
            </div>
            <!--/ Image grid -->
          </div>
          
        </section>
      </div>
    </div>
  </div>
    
 <script src="../assets/js/vendors.min.js"></script>
    <!-- BEGIN VENDOR JS-->
    <!-- BEGIN PAGE VENDOR JS-->
    <script src="../assets/js/masonry.pkgd.min.js"></script>
    <!-- <script src="../assets/css/photo-swipe/photoswipe.min.js"></script> -->
    <script src="../assets/css/photo-swipe/photoswipe-ui-default.min.js"></script>
    <!-- END PAGE VENDOR JS-->
    <!-- BEGIN MODERN JS-->
    <script src="../assets/js/core/app-menu.js"></script>
    <script src="../assets/js/core/app.js"></script>
    <!-- END MODERN JS-->
    <!-- BEGIN PAGE LEVEL JS-->
    <!-- <script src="../assets/js/photo-swipe/photoswipe-script.js"></script> -->
    <!-- END PAGE LEVEL JS-->
    <script>
        var clock;
        $(document).ready(function () {
            var W = $(window).width();
            var H = $(window).height();
            // $('#whole').width(W);
            
        });
         
        function select_img(){
          location.href = "<?php echo base_url('Front/index')?>";         
      
        }
        
        function select_video(){
          location.href = "<?php echo base_url('Front/go_video_index2')?>";    
        }
    </script>
        
</body>
</html>
